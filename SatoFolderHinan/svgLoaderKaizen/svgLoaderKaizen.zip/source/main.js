import { SvgButton } from "./svgLoader";
import { SvgCircleAnalyzer } from "./svgLoader";

let inputButton;

document.addEventListener("DOMContentLoaded", setup);

function setup() {
  inputButton = new SvgButton("#fileInput");
  inputButton.addEventListener('svgLoaded', (event) => {
    //console.log(event);
    const apple = new SvgCircleAnalyzer(event);
    console.log(apple.circles[0]);
  })
}